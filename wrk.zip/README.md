# TIGR-Assignment-2
Group work repo for PR301 assignment 2
Base code written by Thomas Baines, Kelsey Vavasour, Sean Ryan and Jess Ward


Assignment 2 Features List:
1. Supports Piping and Scripting
2. Command line switches
3. Commands parsed from configurable lookup table
4. Parser utilizes regular expressions
5. Displays interpreted output with turtle.py
6. System contains unit tests
7. System error traps and handles - Displays informative errors
